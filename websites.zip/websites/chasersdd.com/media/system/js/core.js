<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="robots" content="noindex, nofollow">
<title>One moment, please...</title>
<style>
body {
    background: #F6F7F8;
    color: #303131;
    font-family: sans-serif;
    margin-top: 45vh;
    text-align: center;
}
</style>
</head>
<body>
<h1>Please wait while your request is being verified...</h1>
<form id="wsidchk-form" style="display:none;" action="/z0f76a1d14fd21a8fb5fd0d03e0fdc3d3cedae52f" method="get">
<input type="hidden" id="wsidchk" name="wsidchk"/>
</form>
<script>
(function(){
    var west=+((+!+[])+(+!+[]+[])+(+!+[]+!![]+!![])+(+![]+[])+(+!+[]+!![]+!![]+!![]+!![])+(+!+[]+!![]+[])+(+!+[]+!![]+!![]+!![])+(+!+[]+!![]+!![]+!![]+!![]+[])),
        east=+((+!+[])+(+!+[]+!![]+!![]+!![]+!![]+!![]+[])+(+!+[]+!![])+(+!+[]+!![]+!![]+[])+(+![])+(+!+[]+!![]+!![]+[])+(+!+[]+!![])+(+!+[]+!![]+!![]+!![]+!![]+[])),
        x=function(){try{return !!window.addEventListener;}catch(e){return !!0;} },
        y=function(y,z){x() ? document.addEventListener("DOMContentLoaded",y,z) : document.attachEvent("onreadystatechange",y);};
    y(function(){
        document.getElementById('wsidchk').value = west + east;
        document.getElementById('wsidchk-form').submit();
    }, false);
})();
</script>
</body>
</html>